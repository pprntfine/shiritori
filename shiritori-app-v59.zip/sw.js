/* しりとりアプリ v55 - こうしんが すぐ とどくように 作る
   ・ページ本体(HTML)は ネットワーク優先 → 更新したら 次にひらいたときに 新しい版
   ・アイコン等は キャッシュ優先 → オフラインでも ひらける
   ・外部(ntfy.sh)には 一切 さわらない/ 保存しない */
var CACHE='srt-v59-1';
var ASSETS=['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png'];
self.addEventListener('install',function(e){
  self.skipWaiting();
  e.waitUntil(caches.open(CACHE).then(function(c){ return c.addAll(ASSETS).catch(function(){}); }));
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.filter(function(k){ return k!==CACHE; }).map(function(k){ return caches.delete(k); }));
  }).then(function(){ return self.clients.claim(); }));
});
self.addEventListener('message',function(e){
  if(e.data&&e.data.type==='skip-waiting') self.skipWaiting();
});
self.addEventListener('fetch',function(e){
  var u;
  try{ u=new URL(e.request.url); }catch(err){ return; }
  if(u.origin!==location.origin) return;                   /* ntfy.sh など 外部は さわらない */
  if(e.request.method!=='GET') return;
  var isDoc=(e.request.mode==='navigate')||/\.html?$/i.test(u.pathname)||u.pathname==='/'||/webmanifest$/.test(u.pathname);
  if(isDoc){
    e.respondWith(
      fetch(e.request).then(function(res){
        try{ if(res&&res.status===200){ var cl=res.clone(); caches.open(CACHE).then(function(c){ c.put(e.request,cl); }); } }catch(err){}
        return res;
      }).catch(function(){ return caches.match(e.request).then(function(r){ return r||caches.match('./index.html'); }); })
    );
    return;
  }
  e.respondWith(
    caches.match(e.request).then(function(r){
      return r || fetch(e.request).then(function(res){
        try{ if(res&&res.status===200&&res.type==='basic'){ var cl=res.clone(); caches.open(CACHE).then(function(c){ c.put(e.request,cl); }); } }catch(err){}
        return res;
      });
    })
  );
});
